# RTOS_P2

Compilar:

make
